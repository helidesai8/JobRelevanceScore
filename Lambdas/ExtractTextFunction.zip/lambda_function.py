import json
import boto3
import base64
import mimetypes

s3_client = boto3.client('s3')
dynamodb = boto3.client('dynamodb')
textract_client = boto3.client('textract')

def guess_mime_type(file_name):
    mime_type, _ = mimetypes.guess_type(file_name)
    return mime_type or 'application/octet-stream'

def extract_text_from_s3(bucket, document):
    try:
        print(f'Analyzing document: {document} in bucket: {bucket}')
        
        # Guess the MIME type based on the file extension
        guessed_mime_type = guess_mime_type(document)
        print(f'Guessed MIME type: {guessed_mime_type}')
        
        # Update the object's content type in S3
        s3_client.copy_object(
            Bucket=bucket,
            CopySource={'Bucket': bucket, 'Key': document},
            Key=document,
            MetadataDirective='REPLACE',
            ContentType=guessed_mime_type
        )
        
        # Fetch the updated document metadata
        head_response = s3_client.head_object(Bucket=bucket, Key=document)
        print(f'Head response: {head_response}')
        content_type = head_response['ContentType']
        content_length = head_response['ContentLength']
        print('document',document)
        print(f'Updated document MIME type: {content_type}')
        print(f'Document size: {content_length} bytes')
        
        print('content_type',content_type)
        if content_type not in ['image/png', 'image/jpeg', 'image/tiff', 'application/pdf']:
            raise ValueError(f'Unsupported document MIME type: {content_type}')
        
        if content_length > 5 * 1024 * 1024:  # 5 MB
            raise ValueError(f'Document size exceeds the maximum allowed size of 5 MB')
        
        print(bucket)
        print(document)
        response = textract_client.detect_document_text(Document={'S3Object': {'Bucket': bucket, 'Name': document}})
        print(f'Analysis response: {response}')
        
        text = ''
        for item in response['Blocks']:
            if item['BlockType'] == 'LINE':
                text += item['Text'] + '\n'
        print(f'Extracted text: {text}')
        return text
    except textract_client.exceptions.UnsupportedDocumentException as e:
        print(f'Unsupported document format: {str(e)}')
        raise
    except Exception as e:
        print(f'Error during text extraction: {str(e)}')
        raise

def lambda_handler(event, context):
    try:
        event = json.loads(event['body'])
        document_id = event['DocumentID']

        response = dynamodb.get_item(
            TableName='ResumesTable',
            Key={'DocumentID': {'S': document_id}}
        )
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Document not found'}),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                }
            }

        item = response['Item']
        print(f'DynamoDB item: {item}')
        bucket_name = 'term-project-resume'
        resume_file = item.get('ResumeFile', {}).get('S', '')
        job_description_file = item.get('JobDescriptionFile', {}).get('S', '')
        resume_text = item.get('ResumeContent', {}).get('S', '')
        job_description_text = item.get('JobDescription', {}).get('S', '')
        print(resume_file, job_description_file)

        if resume_file:
            print('In resume_file')
            resume_text = extract_text_from_s3(bucket_name, resume_file)
        
        if job_description_file:
            print('In job_description_file')
            job_description_text = extract_text_from_s3(bucket_name, job_description_file)

        # Update the DynamoDB item with the extracted or provided text
        dynamodb.update_item(
            TableName='ResumesTable',
            Key={'DocumentID': {'S': document_id}},
            UpdateExpression='SET ResumeContent = :resume, JobDescription = :job_desc',
            ExpressionAttributeValues={
                ':resume': {'S': resume_text},
                ':job_desc': {'S': job_description_text}
            }
        )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Text extracted and saved successfully', 'DocumentID': document_id}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }

    except json.JSONDecodeError as e:
        print(f"Error decoding JSON: {e}")
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'Invalid JSON in request body'}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
    except KeyError as e:
        print(f"Missing required key: {e}")
        return {
            'statusCode': 400,
            'body': json.dumps({'message': f'Missing required field: {str(e)}'}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
    except s3_client.exceptions.NoSuchBucket as e:
        print(e)
        return {
            'statusCode': 400,
            'body': json.dumps({'message': 'The specified bucket does not exist', 'error': str(e)}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
    except ValueError as e:
        print(e)
        return {
            'statusCode': 400,
            'body': json.dumps({'message': str(e)}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
    except Exception as e:
        print(f"Unexpected error: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'An unexpected error occurred', 'error': str(e)}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
