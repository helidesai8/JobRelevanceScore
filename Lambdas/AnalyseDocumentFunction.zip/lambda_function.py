import json
import boto3

dynamodb = boto3.client('dynamodb')
s3 = boto3.client('s3')
comprehend_client = boto3.client(
    'comprehend',
    aws_access_key_id='AKIAUAV7AC4K2LTFMR5K',
    aws_secret_access_key='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'
)
def calculate_jaccard_similarity(set1, set2):
    intersection = len(set1.intersection(set2))
    union = len(set1.union(set2))
    return (intersection / union) if union != 0 else 0

def get_s3_file_content(bucket, key):
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        content = response['Body'].read().decode('utf-8')
        return content
    except Exception as e:
        print(f"Error getting object {key} from bucket {bucket}. Make sure they exist and your bucket is in the same region as this function.")
        print(e)
        raise e

def lambda_handler(event, context):
    try:
        event = json.loads(event['body'])
        document_id = event['DocumentID']

        response = dynamodb.get_item(
            TableName='ResumesTable',
            Key={'DocumentID': {'S': document_id}}
        )
        
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps({'message': 'Document not found'}),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                }
            }

        item = response['Item']
        print(item)
        bucket_name = 'term-project-resume'
        job_description_text = item.get('JobDescription', {}).get('S', '')
        resume_text = item.get('ResumeContent', {}).get('S', '')

        if not job_description_text or not resume_text:
            return {
                'statusCode': 400,
                'body': json.dumps({'message': 'Job description or resume text is missing'}),
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': '*',
                    'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                }
            }

        job_entities = comprehend_client.detect_entities(Text=job_description_text, LanguageCode='en')['Entities']
        resume_entities = comprehend_client.detect_entities(Text=resume_text, LanguageCode='en')['Entities']
        if job_entities:
            job_entities = [x for x in job_entities if x['Type']=='TITLE']
        if resume_entities:
            resume_entities = [x for x in resume_entities if x['Type']=='TITLE']
        job_keywords = set(entity['Text'].lower() for entity in job_entities)
        resume_keywords = set(entity['Text'].lower() for entity in resume_entities)
        common_keywords = job_keywords.intersection(resume_keywords)
        relevance_score = calculate_jaccard_similarity(job_keywords, resume_keywords)
        unique_keywords = list(set(job_keywords) - set(common_keywords))

        analysis_results = {
            'resume_text': resume_text,
            'job_description_text': job_description_text,
            'job_entities': job_entities,
            'resume_entities': resume_entities,
            'common_keywords': list(common_keywords),
            'unique_keywords': unique_keywords,
            'relevance_score': relevance_score
        }
        dynamodb.update_item(
            TableName='ResumesTable',
            Key={'DocumentID': {'S': document_id}},
            UpdateExpression='SET AnalysisResults = :results',
            ExpressionAttributeValues={':results': {'S': json.dumps(analysis_results)}}
        )

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Analysis complete', 'analysis_results': analysis_results}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
    except Exception as e:
        print(f"Error processing request: {e}")
        return {
            'statusCode': 500,
            'body': json.dumps({'message': 'Internal server error'}),
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Headers': '*',
                'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
            }
        }
