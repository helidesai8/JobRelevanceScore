import json
import boto3
import uuid
from requests_toolbelt.multipart import decoder
import base64
import os
import mimetypes

s3_client = boto3.client('s3')
dynamodb = boto3.client('dynamodb')

def parse_content_disposition(content_disposition):
    """
    Parse the Content-Disposition header to extract the filename.
    """
    filename = None
    name = None
    disposition, params = content_disposition.split(';', 1)
    for param in params.split(';'):
        param = param.strip()
        if param.startswith('filename'):
            filename = param.split('=', 1)[1].strip('"')
        elif param.startswith('name'):
            name = param.split('=', 1)[1].strip('"')
    return disposition, name, filename

def lambda_handler(event, context):
    document_id = str(uuid.uuid4())
    print(event)
    content_type = event['headers'].get('Content-Type') or event['headers'].get('content-type')
    body = event['body']
    
    # Check if the body is base64 encoded and decode it if necessary
    if event.get('isBase64Encoded'):
        body = base64.b64decode(body)
    else:
        body = body.encode('utf-8')
    print(body)
    # Decode the multipart form data
    multipart_data = decoder.MultipartDecoder(body, content_type)
    print(multipart_data)
    item = {'DocumentID': {'S': document_id}}

    supported_formats = ['.pdf', '.jpeg', '.jpg', '.png', '.tiff']

    for part in multipart_data.parts:
        content_disposition = part.headers[b'Content-Disposition'].decode()
        disposition, name, filename = parse_content_disposition(content_disposition)

        print(f'Processing part: content_disposition={content_disposition}, name={name}, filename={filename}')
        
        if name == "resume_text":
            item['ResumeContent'] = {'S': part.text}
        elif name == "job_description_text":
            item['JobDescription'] = {'S': part.text}
        elif name == "resume_file" and filename:
            extension = os.path.splitext(filename)[-1].lower()
            if extension not in supported_formats:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': f'Unsupported file format: {extension}'}),
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    }
                }
            resume_file_key = f'{document_id}/resume{extension}'
            s3_client.put_object(Bucket='term-project-resume', Key=resume_file_key, Body=part.content, ContentType=part.headers[b'Content-Type'].decode())
            item['ResumeFile'] = {'S': resume_file_key}
        elif name == "job_description_file" and filename:
            extension = os.path.splitext(filename)[-1].lower()
            if extension not in supported_formats:
                return {
                    'statusCode': 400,
                    'body': json.dumps({'message': f'Unsupported file format: {extension}'}),
                    'headers': {
                        'Access-Control-Allow-Origin': '*',
                        'Access-Control-Allow-Headers': '*',
                        'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
                    }
                }
            job_description_file_key = f'{document_id}/job_description{extension}'
            s3_client.put_object(Bucket='term-project-resume', Key=job_description_file_key, Body=part.content, ContentType=part.headers[b'Content-Type'].decode())
            item['JobDescriptionFile'] = {'S': job_description_file_key}
    
    print(item)
    dynamodb.put_item(TableName='ResumesTable', Item=item)
    
    return {
        'statusCode': 200,
        'body': json.dumps({'message': 'Document uploaded successfully', 'DocumentID': document_id}),
        'headers': {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Headers': '*',
            'Access-Control-Allow-Methods': 'OPTIONS,POST,GET',
        }
    }
